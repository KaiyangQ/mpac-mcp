#!/usr/bin/env python3
"""
MPAC Agent — Join a collaborative coding session.

Usage:
    python run.py

You will be prompted for:
  1. Coordinator address (the host will give you this)
  2. Your Anthropic API key
  3. Your name
"""
import asyncio
import json
import os
import sys
import logging

logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)


def setup():
    """Interactive setup — collect config from user."""
    print()
    print("  ============================================")
    print("    MPAC Collaborative Agent — Setup")
    print("  ============================================")
    print()

    # Check if config exists
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    if os.path.exists(config_path):
        with open(config_path) as f:
            cfg = json.load(f)
        print(f"  Found existing config.json")
        print(f"  Name: {cfg.get('name', '?')}")
        print(f"  Server: {cfg.get('server', '?')}")
        print(f"  API Key: {cfg.get('anthropic', {}).get('api_key', '?')[:15]}...")
        print()
        reuse = input("  Use this config? (y/n): ").strip().lower()
        if reuse == "y":
            return cfg
        print()

    # Collect info
    print("  Enter the coordinator address (the host will give you this).")
    print("  Example: ws://192.168.1.42:8766")
    print()
    server = input("  Coordinator address: ").strip()
    if not server:
        server = "ws://localhost:8766"
    if not server.startswith("ws://") and not server.startswith("wss://"):
        server = "ws://" + server

    print()
    print("  Enter your Anthropic API key.")
    print("  Get one at: https://console.anthropic.com/settings/keys")
    print()
    api_key = input("  API key (sk-ant-...): ").strip()

    print()
    name = input("  Your name (e.g., Bob): ").strip()
    if not name:
        name = "Agent"

    print()
    model = "claude-sonnet-4-6"
    print(f"  Model: {model} (default)")

    # Save config
    cfg = {
        "name": name,
        "server": server,
        "session_id": "collab-session-001",
        "anthropic": {
            "api_key": api_key,
            "model": model,
        }
    }
    with open(config_path, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"\n  Config saved to config.json (you won't need to enter this again)")
    return cfg


async def main():
    from mpac_protocol import MPACAgent

    cfg = setup()

    name = cfg["name"]
    server_uri = cfg["server"]
    session_id = cfg.get("session_id", "collab-session-001")
    api_key = cfg["anthropic"]["api_key"]
    model = cfg["anthropic"].get("model", "claude-sonnet-4-6")

    print()
    print(f"  Connecting to {server_uri} as {name}...")
    print()

    agent = MPACAgent(
        name=name,
        api_key=api_key,
        model=model,
        role_description=f"Collaborative AI coding agent operated by {name}",
    )

    try:
        await agent.connect(server_uri, session_id)
    except Exception as e:
        print(f"\n  ERROR: Cannot connect to {server_uri}")
        print(f"  {e}")
        print()
        print("  Make sure:")
        print("    1. The host has started the coordinator")
        print("    2. The address is correct")
        print("    3. You are on the same network (or using ngrok)")
        return

    try:
        await agent.run_interactive()
    except (KeyboardInterrupt, EOFError):
        pass

    await agent.close()
    print("\n  Disconnected.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n  Bye!")
