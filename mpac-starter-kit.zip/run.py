#!/usr/bin/env python3
"""
MPAC Agent — Join a collaborative coding session.

Usage:
    python run.py                           # use config.json (interactive setup if missing)
    python run.py wss://host.ngrok.dev      # override server from command line

You will be prompted for:
  1. Coordinator address (the host will give you this)
  2. Your Anthropic API key
  3. Your name
"""
import asyncio
import json
import os
import sys
import logging

logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)


def normalize_server(server: str) -> str:
    """Ensure server URI has a ws:// or wss:// prefix."""
    server = server.strip()
    if not server:
        return "ws://localhost:8766"
    if not server.startswith("ws://") and not server.startswith("wss://"):
        server = "ws://" + server
    return server


def interactive_setup(config_path: str, cli_server: str = None) -> dict:
    """Interactive setup — collect config from user.

    If cli_server is provided, it overrides any existing server in config.
    Missing fields in existing config are prompted for.
    """
    print()
    print("  ============================================")
    print("    MPAC Collaborative Agent — Setup")
    print("  ============================================")
    print()

    # Load existing config if present
    cfg = {}
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
        except (json.JSONDecodeError, OSError):
            cfg = {}

        if cfg:
            print(f"  Found existing config.json")
            print(f"  Name:    {cfg.get('name', '(missing)')}")
            print(f"  Server:  {cfg.get('server', '(missing)')}")
            api_key = cfg.get('anthropic', {}).get('api_key', '')
            print(f"  API Key: {api_key[:15] + '...' if api_key else '(missing)'}")
            print()

            # If CLI server provided, override
            if cli_server:
                cfg["server"] = normalize_server(cli_server)
                print(f"  Overriding server with: {cfg['server']}")
                print()

            # Check if all required fields are present
            has_name = bool(cfg.get("name"))
            has_server = bool(cfg.get("server"))
            has_key = bool(cfg.get("anthropic", {}).get("api_key"))

            if has_name and has_server and has_key:
                reuse = input("  Use this config? (y/n): ").strip().lower()
                if reuse == "y":
                    _save_config(config_path, cfg)
                    return cfg
                print()
            else:
                print("  Config is incomplete. Filling in missing fields...")
                print()

    # Collect missing fields
    if not cfg.get("server"):
        if cli_server:
            cfg["server"] = normalize_server(cli_server)
            print(f"  Using server from command line: {cfg['server']}")
        else:
            print("  Enter the coordinator address (the host will give you this).")
            print("  Example: ws://192.168.1.42:8766  or  wss://xxx.ngrok-free.dev")
            print()
            cfg["server"] = normalize_server(input("  Coordinator address: "))
        print()

    if not cfg.get("anthropic", {}).get("api_key"):
        print("  Enter your Anthropic API key.")
        print("  Get one at: https://console.anthropic.com/settings/keys")
        print()
        api_key = input("  API key (sk-ant-...): ").strip()
        cfg.setdefault("anthropic", {})["api_key"] = api_key
        print()

    if not cfg.get("name"):
        name = input("  Your name (e.g., Bob): ").strip()
        cfg["name"] = name if name else "Agent"
        print()

    # Fill in defaults
    cfg.setdefault("session_id", "collab-session-001")
    cfg.setdefault("anthropic", {}).setdefault("model", "claude-sonnet-4-6")

    _save_config(config_path, cfg)
    print(f"  Config saved to config.json")
    return cfg


def _save_config(config_path: str, cfg: dict):
    with open(config_path, "w") as f:
        json.dump(cfg, f, indent=2)


async def main():
    from mpac_protocol import MPACAgent

    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    cli_server = sys.argv[1] if len(sys.argv) > 1 else None

    cfg = interactive_setup(config_path, cli_server)

    name = cfg["name"]
    server_uri = cfg["server"]
    session_id = cfg.get("session_id", "collab-session-001")
    api_key = cfg["anthropic"]["api_key"]
    model = cfg["anthropic"].get("model", "claude-sonnet-4-6")

    print()
    print(f"  Connecting to {server_uri} as {name}...")
    print()

    agent = MPACAgent(
        name=name,
        api_key=api_key,
        model=model,
        role_description=f"Collaborative AI coding agent operated by {name}",
    )

    try:
        await agent.connect(server_uri, session_id)
    except Exception as e:
        print(f"\n  ERROR: Cannot connect to {server_uri}")
        print(f"  {e}")
        print()
        print("  Make sure:")
        print("    1. The host has started the coordinator")
        print("    2. The address is correct")
        print("    3. You are on the same network (or using ngrok)")
        return

    try:
        await agent.run_interactive()
    except (KeyboardInterrupt, EOFError):
        pass

    await agent.close()
    print("\n  Disconnected.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n  Bye!")
